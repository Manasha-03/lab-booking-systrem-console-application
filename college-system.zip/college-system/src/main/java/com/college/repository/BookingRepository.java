package com.college.repository;

import com.college.entity.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {

    Optional<Booking> findByRoomIdAndPeriodIdAndBookingDate(Long roomId, Long periodId, LocalDate date);

    List<Booking> findByBookingDateOrderByPeriodPeriodNumber(LocalDate date);

    @Modifying
    @Query("DELETE FROM Booking b WHERE b.period.department.id = :deptId")
    void deleteByPeriodDepartmentId(@Param("deptId") Long deptId);
}
