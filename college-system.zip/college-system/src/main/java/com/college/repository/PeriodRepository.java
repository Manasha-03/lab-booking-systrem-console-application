package com.college.repository;

import com.college.entity.Period;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface PeriodRepository extends JpaRepository<Period, Long> {
    List<Period> findByDepartmentIdOrderByPeriodNumber(Long departmentId);
    void deleteByDepartmentId(Long departmentId);
}
