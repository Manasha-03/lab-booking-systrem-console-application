package com.college.exception;

public class CollegeException extends RuntimeException {
    public CollegeException(String message) {
        super(message);
    }
}
