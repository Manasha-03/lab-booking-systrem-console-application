package com.college.controller;

import com.college.dto.Dto;
import com.college.dto.SystemViewRes;
import com.college.service.*;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class AdminController {

    private final CollegeService collegeService;
    private final DepartmentService departmentService;
    private final BookingService bookingService;

    // ── College ──────────────────────────────────────────────────────────────

    @PostMapping("/college")
    public ResponseEntity<Dto.ApiRes<Dto.CollegeRes>> saveCollege(@RequestBody Dto.CollegeReq req) {
        Dto.CollegeRes res = collegeService.saveCollege(req);
        return ResponseEntity.ok(Dto.ApiRes.ok("College saved.", res));
    }

    @GetMapping("/college")
    public ResponseEntity<Dto.ApiRes<Dto.CollegeRes>> getCollege() {
        return ResponseEntity.ok(Dto.ApiRes.ok("College details.", collegeService.getCollege()));
    }

    // ── Departments ───────────────────────────────────────────────────────────

    @PostMapping("/departments")
    public ResponseEntity<Dto.ApiRes<List<String>>> addDepartments(@RequestBody Dto.DeptNamesReq req) {
        List<String> added = departmentService.addDepartments(req.getNames());
        return ResponseEntity.ok(Dto.ApiRes.ok("Departments added.", added));
    }

    @GetMapping("/departments")
    public ResponseEntity<Dto.ApiRes<List<Dto.DeptRes>>> getAllDepartments() {
        return ResponseEntity.ok(Dto.ApiRes.ok("Departments.", departmentService.getAllDepartments()));
    }

    @DeleteMapping("/departments/{id}")
    public ResponseEntity<Dto.ApiRes<Void>> removeDepartment(@PathVariable Long id) {
        departmentService.removeDepartment(id);
        return ResponseEntity.ok(Dto.ApiRes.ok("Department removed."));
    }

    // ── System View ───────────────────────────────────────────────────────────

    @GetMapping("/system")
    public ResponseEntity<Dto.ApiRes<SystemViewRes>> viewSystem() {
        Dto.CollegeRes college = collegeService.getCollege();
        List<Dto.DeptRes> departments = departmentService.getAllDepartments();
        List<Dto.BookingRes> bookings = bookingService.getAllBookings();

        SystemViewRes view = new SystemViewRes();
        view.setCollege(college);
        view.setDepartments(departments);
        view.setBookings(bookings);
        return ResponseEntity.ok(Dto.ApiRes.<SystemViewRes>ok("System view.", view));
    }

    // ── Bookings ──────────────────────────────────────────────────────────────

    @PostMapping("/bookings/reset")
    public ResponseEntity<Dto.ApiRes<Void>> resetBookings() {
        bookingService.resetBookings();
        return ResponseEntity.ok(Dto.ApiRes.ok("All bookings reset."));
    }

    @GetMapping("/bookings/search")
    public ResponseEntity<Dto.ApiRes<List<Dto.BookingRes>>> searchBookings(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return ResponseEntity.ok(Dto.ApiRes.ok("Bookings on " + date, bookingService.searchByDate(date)));
    }

    @GetMapping("/bookings")
    public ResponseEntity<Dto.ApiRes<List<Dto.BookingRes>>> allBookings() {
        return ResponseEntity.ok(Dto.ApiRes.ok("All bookings.", bookingService.getAllBookings()));
    }
}
