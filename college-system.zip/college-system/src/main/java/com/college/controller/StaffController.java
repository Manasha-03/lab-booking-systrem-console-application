package com.college.controller;

import com.college.dto.Dto;
import com.college.service.BookingService;
import com.college.service.DepartmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/staff")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class StaffController {

    private final BookingService bookingService;
    private final DepartmentService departmentService;

    @GetMapping("/departments")
    public ResponseEntity<Dto.ApiRes<List<Dto.DeptRes>>> getConfiguredDepartments() {
        List<Dto.DeptRes> configured = departmentService.getAllDepartments()
                .stream()
                .filter(Dto.DeptRes::isConfigured)
                .toList();
        return ResponseEntity.ok(Dto.ApiRes.ok("Configured departments.", configured));
    }

    @GetMapping("/departments/{deptId}/schedule")
    public ResponseEntity<Dto.ApiRes<Dto.DeptRes>> getSchedule(@PathVariable Long deptId) {
        return ResponseEntity.ok(Dto.ApiRes.ok("Schedule.", departmentService.getDepartment(deptId)));
    }

    @GetMapping("/departments/{deptId}/availability")
    public ResponseEntity<Dto.ApiRes<Dto.AvailabilityRes>> getAvailability(
            @PathVariable Long deptId,
            @RequestParam String currentTime,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        if (date == null) date = LocalDate.now();
        Dto.AvailabilityRes res = bookingService.getAvailability(deptId, currentTime, date);
        return ResponseEntity.ok(Dto.ApiRes.ok(res.getMessage(), res));
    }

    @PostMapping("/book")
    public ResponseEntity<Dto.ApiRes<Dto.BookingRes>> book(
            @RequestParam Long userId,
            @RequestBody Dto.BookingReq req) {
        Dto.BookingRes booking = bookingService.bookRoom(userId, req);
        return ResponseEntity.ok(Dto.ApiRes.ok("Booked Successfully!", booking));
    }
}
