package com.college.controller;

import com.college.dto.Dto;
import com.college.service.DepartmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/office")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class OfficeController {

    private final DepartmentService departmentService;

    @GetMapping("/departments")
    public ResponseEntity<Dto.ApiRes<List<Dto.DeptRes>>> getDepartments() {
        return ResponseEntity.ok(Dto.ApiRes.ok("Departments.", departmentService.getAllDepartments()));
    }

    @PostMapping("/departments/{deptId}/configure")
    public ResponseEntity<Dto.ApiRes<Dto.DeptRes>> configureDepartment(
            @PathVariable Long deptId,
            @RequestBody Dto.DeptConfigReq req) {
        Dto.DeptRes dept = departmentService.configureDepartment(deptId, req);
        return ResponseEntity.ok(Dto.ApiRes.ok("Department configured successfully.", dept));
    }

    @GetMapping("/departments/{deptId}")
    public ResponseEntity<Dto.ApiRes<Dto.DeptRes>> getDepartment(@PathVariable Long deptId) {
        return ResponseEntity.ok(Dto.ApiRes.ok("Department.", departmentService.getDepartment(deptId)));
    }
}
