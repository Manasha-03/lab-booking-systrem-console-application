package com.college.dto;

import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDate;
import java.util.List;

// ─── Request DTOs ─────────────────────────────────────────────────────────────

@Getter @Setter @NoArgsConstructor @AllArgsConstructor
class CollegeRequest {
    @NotBlank(message = "College name is required")
    public String name;
    @NotBlank(message = "Start time is required")
    public String startTime;
    @NotBlank(message = "Close time is required")
    public String closeTime;
}

// ─── Response DTOs ─────────────────────────────────────────────────────────────

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
class ApiResponse<T> {
    public boolean success;
    public String message;
    public T data;

    public static <T> ApiResponse<T> ok(String message, T data) {
        return new ApiResponse<>(true, message, data);
    }

    public static <T> ApiResponse<T> ok(String message) {
        return new ApiResponse<>(true, message, null);
    }
}

// ────────────────────────────────────────────────────────────────────────────────

/**
 * Central DTO holder class used across controllers.
 */
public class Dto {

    // ── College ──
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor
    public static class CollegeReq {
        @NotBlank public String name;
        @NotBlank public String startTime;
        @NotBlank public String closeTime;
    }

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class CollegeRes {
        public Long id;
        public String name;
        public String startTime;
        public String closeTime;
    }

    // ── Department ──
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor
    public static class DeptNameReq {
        @NotBlank public String name;
    }

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor
    public static class DeptNamesReq {
        @NotNull @Size(min=1) public List<String> names;
    }

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class DeptRes {
        public Long id;
        public String name;
        public boolean configured;
        public String startTime;
        public String closeTime;
        public String morningBreak;
        public String lunchBreak;
        public String eveningBreak;
        public Integer minutesPerPeriod;
        public List<PeriodRes> periods;
        public List<RoomRes> classrooms;
        public List<RoomRes> labs;
    }

    // ── Department Configure ──
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor
    public static class DeptConfigReq {
        @NotBlank public String startTime;
        @NotBlank public String closeTime;
        @NotBlank public String morningBreak;   // "10.55 am - 11.10 am"
        @NotBlank public String lunchBreak;
        @NotBlank public String eveningBreak;
        @NotNull  public Integer minutesPerPeriod;
        @NotNull @Size(min=1) public List<String> classrooms;
        @NotNull @Size(min=1) public List<String> labs;
    }

    // ── Period ──
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class PeriodRes {
        public Long id;
        public int periodNumber;
        public String classStartTime;
        public String classEndTime;
        public String bookingStartTime;
        public String bookingEndTime;
    }

    // ── Room ──
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class RoomRes {
        public Long id;
        public String name;
        public String roomType;
        public boolean available;
    }

    // ── User / Auth ──
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor
    public static class RegisterReq {
        @NotBlank public String username;
        @NotBlank public String password;
        public String departmentName;  // for office assistants
        @NotBlank public String role;  // OFFICE_ASSISTANT or STAFF
    }

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor
    public static class LoginReq {
        @NotBlank public String username;
        @NotBlank public String password;
    }

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class UserRes {
        public Long id;
        public String username;
        public String role;
        public String department;
    }

    // ── Booking ──
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor
    public static class BookingReq {
        @NotNull  public Long roomId;
        @NotNull  public Long periodId;
        @NotBlank public String currentTime;   // e.g. "9.00 am"
        public LocalDate bookingDate;
    }

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class BookingRes {
        public Long id;
        public String roomName;
        public String roomType;
        public int periodNumber;
        public String classStartTime;
        public String classEndTime;
        public String bookedAt;
        public LocalDate bookingDate;
        public String bookedBy;
    }

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class AvailabilityRes {
        public Long periodId;
        public int periodNumber;
        public String classStartTime;
        public String classEndTime;
        public String bookingStartTime;
        public String bookingEndTime;
        public List<RoomRes> availableRooms;
        public boolean isOpenForBooking;
        public String message;
    }

    // ── Generic ──
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class ApiRes<T> {
        public boolean success;
        public String message;
        public T data;

        public static <T> ApiRes<T> ok(String message, T data) {
            return ApiRes.<T>builder().success(true).message(message).data(data).build();
        }
        public static <T> ApiRes<T> ok(String msg) {
            return ApiRes.<T>builder().success(true).message(msg).build();
        }
        public static <T> ApiRes<T> fail(String msg) {
            return ApiRes.<T>builder().success(false).message(msg).build();
        }
    }
}
