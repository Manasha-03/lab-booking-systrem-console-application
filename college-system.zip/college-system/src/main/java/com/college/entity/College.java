package com.college.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "college")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class College {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(name = "start_time", nullable = false)
    private String startTime;  // e.g. "9.00 am"

    @Column(name = "close_time", nullable = false)
    private String closeTime;  // e.g. "5.15 pm"
}
