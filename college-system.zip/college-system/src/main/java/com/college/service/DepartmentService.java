package com.college.service;

import com.college.config.TimeUtil;
import com.college.dto.Dto;
import com.college.entity.*;
import com.college.exception.CollegeException;
import com.college.exception.ResourceNotFoundException;
import com.college.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DepartmentService {

    private final DepartmentRepository departmentRepository;
    private final PeriodRepository periodRepository;
    private final RoomRepository roomRepository;
    private final BookingRepository bookingRepository;
    private final CollegeRepository collegeRepository;

    // ── Admin: add department names ──────────────────────────────────────────

    @Transactional
    public List<String> addDepartments(List<String> names) {
        List<String> added = new ArrayList<>();
        for (String name : names) {
            String trimmed = name.trim();
            if (trimmed.isBlank()) continue;
            if (departmentRepository.existsByName(trimmed)) {
                throw new CollegeException("Department already exists: " + trimmed);
            }
            Department dept = Department.builder().name(trimmed).configured(false).build();
            departmentRepository.save(dept);
            added.add(trimmed);
        }
        return added;
    }

    // ── Admin: remove department ─────────────────────────────────────────────

    @Transactional
    public void removeDepartment(Long deptId) {
        Department dept = departmentRepository.findById(deptId)
                .orElseThrow(() -> new ResourceNotFoundException("Department not found"));
        // Remove bookings first (cascade manually because SQLite doesn't enforce FK)
        bookingRepository.deleteByPeriodDepartmentId(deptId);
        periodRepository.deleteByDepartmentId(deptId);
        roomRepository.deleteByDepartmentId(deptId);
        departmentRepository.delete(dept);
    }

    // ── Get all departments ──────────────────────────────────────────────────

    public List<Dto.DeptRes> getAllDepartments() {
        return departmentRepository.findAll().stream()
                .map(this::toDeptRes)
                .collect(Collectors.toList());
    }

    public Dto.DeptRes getDepartment(Long id) {
        Department dept = departmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Department not found"));
        return toDeptRes(dept);
    }

    // ── Office Assistant: configure department ───────────────────────────────

    @Transactional
    public Dto.DeptRes configureDepartment(Long deptId, Dto.DeptConfigReq req) {
        Department dept = departmentRepository.findById(deptId)
                .orElseThrow(() -> new ResourceNotFoundException("Department not found"));

        dept.setStartTime(req.getStartTime().trim().toLowerCase());
        dept.setCloseTime(req.getCloseTime().trim().toLowerCase());
        dept.setMorningBreak(req.getMorningBreak().trim().toLowerCase());
        dept.setLunchBreak(req.getLunchBreak().trim().toLowerCase());
        dept.setEveningBreak(req.getEveningBreak().trim().toLowerCase());
        dept.setMinutesPerPeriod(req.getMinutesPerPeriod());
        dept.setConfigured(true);

        departmentRepository.save(dept);

        // Delete old periods and rooms if reconfiguring
        periodRepository.deleteByDepartmentId(deptId);
        roomRepository.deleteByDepartmentId(deptId);

        // Generate periods
        generatePeriods(dept, req);

        // Save classrooms
        for (String name : req.getClassrooms()) {
            if (name == null || name.isBlank()) continue;
            roomRepository.save(Room.builder()
                    .department(dept).name(name.trim()).roomType(Room.RoomType.CLASSROOM).build());
        }

        // Save labs
        for (String name : req.getLabs()) {
            if (name == null || name.isBlank()) continue;
            roomRepository.save(Room.builder()
                    .department(dept).name(name.trim()).roomType(Room.RoomType.LAB).build());
        }

        return toDeptRes(dept);
    }

    /**
     * Generate periods based on department times and breaks.
     * Logic:
     *  - Breaks are parsed from strings like "10.55 am - 11.10 am"
     *  - P1 starts at dept.startTime
     *  - booking window for Pn = class start time - minutesPerPeriod (i.e. 15 min before class starts)
     *    Actually: booking window = [prevEndOrBreakStart, classStart]
     *  - First 6 periods use minutesPerPeriod; last 2 fill remaining time equally
     */
    private void generatePeriods(Department dept, Dto.DeptConfigReq req) {
        int mpp = req.getMinutesPerPeriod();

        // Parse breaks: "10.55 am - 11.10 am"
        // Split on lookahead for digit after optional spaces and dash
        String[] morningParts = req.getMorningBreak().trim().toLowerCase().split("\\s*-\\s*(?=[0-9])");
        String morningStart = morningParts[0].trim();
        String morningEnd   = morningParts[1].trim();

        String[] lunchParts = req.getLunchBreak().trim().toLowerCase().split("\\s*-\\s*(?=[0-9])");
        String lunchStart = lunchParts[0].trim();
        String lunchEnd   = lunchParts[1].trim();

        String[] eveningParts = req.getEveningBreak().trim().toLowerCase().split("\\s*-\\s*(?=[0-9])");
        String eveningStart = eveningParts[0].trim();
        String eveningEnd   = eveningParts[1].trim();

        // Booking window logic (matches original console app exactly):
        // P1: bookingWindow = [college.startTime, dept.startTime]        (college opens -> P1 class starts)
        // P2: bookingWindow = [P2.classStart - 15min, P2.classStart]
        // P3: bookingWindow = [morningBreakStart, morningBreakEnd]        (book during morning break)
        // P4: bookingWindow = [P4.classStart - 15min, P4.classStart]
        // P5: bookingWindow = [P5.classStart - 15min, P5.classStart]      (book during lunch)
        // P6: bookingWindow = [P6.classStart - 15min, P6.classStart]
        // P7: bookingWindow = [eveningBreakStart, eveningBreakEnd]         (book during evening break)
        // P8: bookingWindow = [P8.classStart - 15min, P8.classStart]

        // Retrieve college start time for P1 booking window
        String collegeStart = collegeRepository.findAll().stream()
                .findFirst()
                .map(College::getStartTime)
                .orElse(TimeUtil.subtractMinutes(dept.getStartTime(), 15));

        List<String[]> schedule = new ArrayList<>();
        // [classStart, classEnd, bookStart, bookEnd]

        // P1
        String p1Start = dept.getStartTime();
        String p1End   = TimeUtil.addMinutes(p1Start, mpp);
        schedule.add(new String[]{p1Start, p1End, collegeStart, p1Start});

        // P2 (ends at morning break start)
        String p2Start = p1End;
        String p2End   = morningStart;
        schedule.add(new String[]{p2Start, p2End, TimeUtil.subtractMinutes(p2Start, 15), p2Start});

        // P3 (after morning break, booking window = morning break)
        String p3Start = morningEnd;
        String p3End   = TimeUtil.addMinutes(p3Start, mpp);
        schedule.add(new String[]{p3Start, p3End, morningStart, morningEnd});

        // P4 (ends at lunch start)
        String p4Start = p3End;
        String p4End   = lunchStart;
        schedule.add(new String[]{p4Start, p4End, TimeUtil.subtractMinutes(p4Start, 15), p4Start});

        // P5 (after lunch, booking window = last 15 min of lunch)
        String p5Start = lunchEnd;
        String p5End   = TimeUtil.addMinutes(p5Start, mpp);
        schedule.add(new String[]{p5Start, p5End, TimeUtil.subtractMinutes(p5Start, 15), p5Start});

        // P6 (ends at evening break start)
        String p6Start = p5End;
        String p6End   = eveningStart;
        schedule.add(new String[]{p6Start, p6End, TimeUtil.subtractMinutes(p6Start, 15), p6Start});

        // P7 (after evening break, booking window = evening break)
        String p7Start = eveningEnd;
        String p7End   = TimeUtil.addMinutes(p7Start, 45);
        schedule.add(new String[]{p7Start, p7End, eveningStart, eveningEnd});

        // P8 (till dept close)
        String p8Start = p7End;
        String p8End   = dept.getCloseTime();
        schedule.add(new String[]{p8Start, p8End, TimeUtil.subtractMinutes(p8Start, 15), p8Start});

        // Persist periods
        for (int i = 0; i < schedule.size(); i++) {
            String[] s = schedule.get(i);
            periodRepository.save(Period.builder()
                    .department(dept)
                    .periodNumber(i + 1)
                    .classStartTime(s[0])
                    .classEndTime(s[1])
                    .bookingStartTime(s[2])
                    .bookingEndTime(s[3])
                    .build());
        }
    }

    // ── Admin: reset bookings ────────────────────────────────────────────────

    @Transactional
    public void resetAllBookings() {
        bookingRepository.deleteAll();
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    public Department getDeptEntity(Long id) {
        return departmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Department not found"));
    }

    public List<Period> getPeriodsForDept(Long deptId) {
        return periodRepository.findByDepartmentIdOrderByPeriodNumber(deptId);
    }

    public List<Room> getRoomsForDept(Long deptId) {
        return roomRepository.findByDepartmentId(deptId);
    }

    private Dto.DeptRes toDeptRes(Department d) {
        List<Period> periods = periodRepository.findByDepartmentIdOrderByPeriodNumber(d.getId());
        List<Room> rooms = roomRepository.findByDepartmentId(d.getId());

        List<Dto.PeriodRes> periodResList = periods.stream().map(p ->
                Dto.PeriodRes.builder()
                        .id(p.getId())
                        .periodNumber(p.getPeriodNumber())
                        .classStartTime(p.getClassStartTime())
                        .classEndTime(p.getClassEndTime())
                        .bookingStartTime(p.getBookingStartTime())
                        .bookingEndTime(p.getBookingEndTime())
                        .build()
        ).collect(Collectors.toList());

        List<Dto.RoomRes> classrooms = rooms.stream()
                .filter(r -> r.getRoomType() == Room.RoomType.CLASSROOM)
                .map(r -> Dto.RoomRes.builder().id(r.getId()).name(r.getName()).roomType("CLASSROOM").build())
                .collect(Collectors.toList());

        List<Dto.RoomRes> labs = rooms.stream()
                .filter(r -> r.getRoomType() == Room.RoomType.LAB)
                .map(r -> Dto.RoomRes.builder().id(r.getId()).name(r.getName()).roomType("LAB").build())
                .collect(Collectors.toList());

        return Dto.DeptRes.builder()
                .id(d.getId())
                .name(d.getName())
                .configured(d.isConfigured())
                .startTime(d.getStartTime())
                .closeTime(d.getCloseTime())
                .morningBreak(d.getMorningBreak())
                .lunchBreak(d.getLunchBreak())
                .eveningBreak(d.getEveningBreak())
                .minutesPerPeriod(d.getMinutesPerPeriod())
                .periods(periodResList)
                .classrooms(classrooms)
                .labs(labs)
                .build();
    }
}
