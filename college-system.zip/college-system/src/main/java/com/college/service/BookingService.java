package com.college.service;

import com.college.config.TimeUtil;
import com.college.dto.Dto;
import com.college.entity.*;
import com.college.exception.CollegeException;
import com.college.exception.ResourceNotFoundException;
import com.college.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BookingService {

    private final BookingRepository bookingRepository;
    private final PeriodRepository periodRepository;
    private final RoomRepository roomRepository;
    private final UserRepository userRepository;
    private final CollegeRepository collegeRepository;

    /**
     * Get available rooms for a department at the given current time.
     * FIX: Accept ANY time within a booking window, not just the exact window-start time.
     * Also validate college open hours.
     */
    public Dto.AvailabilityRes getAvailability(Long deptId, String currentTime, LocalDate date) {
        currentTime = currentTime.trim().toLowerCase();

        // Validate college hours
        College college = collegeRepository.findAll().stream().findFirst().orElseThrow(() -> new ResourceNotFoundException("College not configured yet"));
        if (TimeUtil.isBefore(currentTime, college.getStartTime()) ||
            TimeUtil.isAfter(currentTime, college.getCloseTime())) {
            return Dto.AvailabilityRes.builder()
                    .isOpenForBooking(false)
                    .message("College is closed. Hours: " + college.getStartTime() + " - " + college.getCloseTime())
                    .availableRooms(Collections.emptyList())
                    .build();
        }

        // Find which booking window is currently active
        List<Period> periods = periodRepository.findByDepartmentIdOrderByPeriodNumber(deptId);
        Period activePeriod = null;
        for (Period p : periods) {
            if (TimeUtil.isWithinWindow(currentTime, p.getBookingStartTime(), p.getBookingEndTime())) {
                activePeriod = p;
                break;
            }
        }

        if (activePeriod == null) {
            return Dto.AvailabilityRes.builder()
                    .isOpenForBooking(false)
                    .message("No booking window is currently open. Please check the schedule.")
                    .availableRooms(Collections.emptyList())
                    .build();
        }

        // Find all rooms for the dept
        List<Room> allRooms = roomRepository.findByDepartmentId(deptId);

        // Find already booked room IDs for this period+date
        final Period fp = activePeriod;
        Set<Long> bookedRoomIds = allRooms.stream()
                .filter(r -> bookingRepository.findByRoomIdAndPeriodIdAndBookingDate(r.getId(), fp.getId(), date).isPresent())
                .map(Room::getId)
                .collect(Collectors.toSet());

        List<Dto.RoomRes> availableRooms = allRooms.stream()
                .map(r -> Dto.RoomRes.builder()
                        .id(r.getId())
                        .name(r.getName())
                        .roomType(r.getRoomType().name())
                        .available(!bookedRoomIds.contains(r.getId()))
                        .build())
                .collect(Collectors.toList());

        return Dto.AvailabilityRes.builder()
                .periodId(activePeriod.getId())
                .periodNumber(activePeriod.getPeriodNumber())
                .classStartTime(activePeriod.getClassStartTime())
                .classEndTime(activePeriod.getClassEndTime())
                .bookingStartTime(activePeriod.getBookingStartTime())
                .bookingEndTime(activePeriod.getBookingEndTime())
                .availableRooms(availableRooms)
                .isOpenForBooking(true)
                .message("Booking window open for Period " + activePeriod.getPeriodNumber())
                .build();
    }

    /**
     * Book a room.
     * Rules:
     *  1. Validate college open hours.
     *  2. currentTime must fall within period's booking window.
     *  3. Room must not already be booked for this period+date.
     *  4. First-come-first-served: whoever books first gets the room.
     */
    @Transactional
    public Dto.BookingRes bookRoom(Long userId, Dto.BookingReq req) {
        String currentTime = req.getCurrentTime().trim().toLowerCase();
        LocalDate date = req.getBookingDate() != null ? req.getBookingDate() : LocalDate.now();

        // Validate college hours
        College college = collegeRepository.findAll().stream().findFirst().orElseThrow(() -> new ResourceNotFoundException("College not configured yet"));
        if (TimeUtil.isBefore(currentTime, college.getStartTime()) ||
            TimeUtil.isAfter(currentTime, college.getCloseTime())) {
            throw new CollegeException("College is closed. Booking not allowed outside college hours: "
                    + college.getStartTime() + " - " + college.getCloseTime());
        }

        // Load period
        Period period = periodRepository.findById(req.getPeriodId())
                .orElseThrow(() -> new ResourceNotFoundException("Period not found"));

        // FIX: Validate current time is within the booking window (not just exact start time)
        if (!TimeUtil.isWithinWindow(currentTime, period.getBookingStartTime(), period.getBookingEndTime())) {
            throw new CollegeException(
                    "Current time " + currentTime + " is not within the booking window ("
                    + period.getBookingStartTime() + " - " + period.getBookingEndTime()
                    + ") for Period " + period.getPeriodNumber());
        }

        // Load room
        Room room = roomRepository.findById(req.getRoomId())
                .orElseThrow(() -> new ResourceNotFoundException("Room not found"));

        // Check if already booked for this period+date (first-come-first-served)
        bookingRepository.findByRoomIdAndPeriodIdAndBookingDate(room.getId(), period.getId(), date)
                .ifPresent(b -> {
                    throw new CollegeException("Room '" + room.getName() +
                            "' is already booked for Period " + period.getPeriodNumber() +
                            " on " + date + " by " + b.getBookedBy().getUsername());
                });

        // Load user
        AppUser user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        // Create booking
        Booking booking = Booking.builder()
                .room(room)
                .period(period)
                .bookedBy(user)
                .bookedAt(currentTime)
                .bookingDate(date)
                .build();

        booking = bookingRepository.save(booking);

        return Dto.BookingRes.builder()
                .id(booking.getId())
                .roomName(room.getName())
                .roomType(room.getRoomType().name())
                .periodNumber(period.getPeriodNumber())
                .classStartTime(period.getClassStartTime())
                .classEndTime(period.getClassEndTime())
                .bookedAt(booking.getBookedAt())
                .bookingDate(booking.getBookingDate())
                .bookedBy(user.getUsername())
                .build();
    }

    /**
     * Search bookings by date.
     */
    public List<Dto.BookingRes> searchByDate(LocalDate date) {
        return bookingRepository.findByBookingDateOrderByPeriodPeriodNumber(date)
                .stream()
                .map(b -> Dto.BookingRes.builder()
                        .id(b.getId())
                        .roomName(b.getRoom().getName())
                        .roomType(b.getRoom().getRoomType().name())
                        .periodNumber(b.getPeriod().getPeriodNumber())
                        .classStartTime(b.getPeriod().getClassStartTime())
                        .classEndTime(b.getPeriod().getClassEndTime())
                        .bookedAt(b.getBookedAt())
                        .bookingDate(b.getBookingDate())
                        .bookedBy(b.getBookedBy().getUsername())
                        .build())
                .collect(Collectors.toList());
    }

    /**
     * Get all bookings (Admin view).
     */
    public List<Dto.BookingRes> getAllBookings() {
        return bookingRepository.findAll()
                .stream()
                .map(b -> Dto.BookingRes.builder()
                        .id(b.getId())
                        .roomName(b.getRoom().getName())
                        .roomType(b.getRoom().getRoomType().name())
                        .periodNumber(b.getPeriod().getPeriodNumber())
                        .classStartTime(b.getPeriod().getClassStartTime())
                        .classEndTime(b.getPeriod().getClassEndTime())
                        .bookedAt(b.getBookedAt())
                        .bookingDate(b.getBookingDate())
                        .bookedBy(b.getBookedBy().getUsername())
                        .build())
                .collect(Collectors.toList());
    }

    /**
     * Reset all bookings (Admin only).
     */
    @Transactional
    public void resetBookings() {
        bookingRepository.deleteAll();
    }
}
