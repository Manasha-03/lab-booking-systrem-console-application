package com.college.service;

import com.college.dto.Dto;
import com.college.entity.College;
import com.college.exception.ResourceNotFoundException;
import com.college.repository.CollegeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@RequiredArgsConstructor
public class CollegeService {

    private final CollegeRepository collegeRepository;

    @Transactional
    public Dto.CollegeRes saveCollege(Dto.CollegeReq req) {
        College college;
        List<College> all = collegeRepository.findAll();
        if (!all.isEmpty()) {
            college = all.get(0);
        } else {
            college = new College();
        }
        college.setName(req.getName());
        college.setStartTime(req.getStartTime().trim().toLowerCase());
        college.setCloseTime(req.getCloseTime().trim().toLowerCase());
        college = collegeRepository.save(college);
        return toRes(college);
    }

    public Dto.CollegeRes getCollege() {
        return collegeRepository.findAll().stream()
                .findFirst()
                .map(this::toRes)
                .orElseThrow(() -> new ResourceNotFoundException("College not configured yet"));
    }

    public College getCollegeEntity() {
        return collegeRepository.findAll().stream()
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("College not configured yet"));
    }

    private Dto.CollegeRes toRes(College c) {
        return Dto.CollegeRes.builder()
                .id(c.getId())
                .name(c.getName())
                .startTime(c.getStartTime())
                .closeTime(c.getCloseTime())
                .build();
    }
}
