# 🏛️ Lab & Classroom Allocation Management System

A full-stack Spring Boot + SQLite + REST API + HTML web application for managing lab and classroom bookings in a college.

---

## 📋 Features

### Admin
- Set college name and working hours
- Add / Remove departments
- View full system (college, departments, periods, rooms, all bookings)
- Search bookings by date
- Reset all bookings

### Office Assistant
- Register with a department
- Configure department: set timings, breaks, periods (auto-generated), classrooms, labs

### Staff
- Register and login
- View department schedule
- Check real-time room availability by entering current time
- Book a room (first-come-first-served per booking window)
- View booking history by date

---

## 🐛 Bugs Fixed from Original Java Console App

| Bug | Fix |
|-----|-----|
| Only exact booking window start time accepted | Any time within booking window `[start, end]` is now accepted |
| `9.10 am` inside window `9.00–9.15` showed "College closed" | Proper window range check with `isWithinWindow()` |
| Trailing-space login failure (`"Anu "`) | All usernames trimmed on register and login |
| Room not re-available after period ends | Each booking is per `room + period + date`; new period = new booking slot |
| First-come-first-served not enforced | Atomic check: if booked, returns "already booked by X" |

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Backend | Spring Boot 3.2 |
| ORM | Spring Data JPA (Hibernate) |
| Database | SQLite (via `sqlite-jdbc` + Hibernate Community Dialect) |
| Build | Maven |
| API | REST (JSON) |
| Frontend | Pure HTML + CSS + JavaScript (Single Page App) |
| Exceptions | Global `@RestControllerAdvice` handler |

---

## 🚀 How to Run

### Prerequisites
- **Java 17+** installed
- **Maven 3.8+** installed

### Steps

```bash
# 1. Navigate into project folder
cd college-system

# 2. Build the project
mvn clean package -DskipTests

# 3. Run the application
java -jar target/college-system-1.0.0.jar
```

The server starts on **http://localhost:8080**

Open your browser and go to: **http://localhost:8080**

> The SQLite database file `college_system.db` is created automatically in the folder where you run the JAR.

---

## 🔐 Default Credentials

| Role | Username | Password |
|------|----------|----------|
| Admin | `admin` | `123` |

Office Assistants and Staff must **Register** first through the web UI.

---

## 📐 API Endpoints

### Auth
| Method | URL | Description |
|--------|-----|-------------|
| POST | `/api/auth/login` | Login |
| POST | `/api/auth/register` | Register (OFFICE_ASSISTANT or STAFF) |

### Admin
| Method | URL | Description |
|--------|-----|-------------|
| POST | `/api/admin/college` | Save/update college details |
| GET | `/api/admin/college` | Get college details |
| POST | `/api/admin/departments` | Add departments |
| GET | `/api/admin/departments` | List all departments |
| DELETE | `/api/admin/departments/{id}` | Remove department |
| GET | `/api/admin/system` | Full system view |
| GET | `/api/admin/bookings` | All bookings |
| GET | `/api/admin/bookings/search?date=YYYY-MM-DD` | Search by date |
| POST | `/api/admin/bookings/reset` | Reset all bookings |

### Office Assistant
| Method | URL | Description |
|--------|-----|-------------|
| GET | `/api/office/departments` | List departments |
| GET | `/api/office/departments/{id}` | Get department |
| POST | `/api/office/departments/{id}/configure` | Configure department |

### Staff
| Method | URL | Description |
|--------|-----|-------------|
| GET | `/api/staff/departments` | Configured departments |
| GET | `/api/staff/departments/{id}/schedule` | Department schedule |
| GET | `/api/staff/departments/{id}/availability?currentTime=9.00 am&date=YYYY-MM-DD` | Room availability |
| POST | `/api/staff/book?userId={id}` | Book a room |

---

## 📁 Project Structure

```
college-system/
├── pom.xml
└── src/
    └── main/
        ├── java/com/college/
        │   ├── CollegeSystemApplication.java
        │   ├── config/
        │   │   ├── DataInitializer.java      ← Seeds admin user
        │   │   └── TimeUtil.java             ← Time parsing & comparison
        │   ├── controller/
        │   │   ├── AdminController.java
        │   │   ├── AuthController.java
        │   │   ├── OfficeController.java
        │   │   └── StaffController.java
        │   ├── dto/
        │   │   ├── Dto.java                  ← All request/response DTOs
        │   │   └── SystemViewRes.java
        │   ├── entity/
        │   │   ├── AppUser.java
        │   │   ├── Booking.java
        │   │   ├── College.java
        │   │   ├── Department.java
        │   │   ├── Period.java
        │   │   └── Room.java
        │   ├── exception/
        │   │   ├── CollegeException.java
        │   │   ├── GlobalExceptionHandler.java
        │   │   ├── ResourceNotFoundException.java
        │   │   └── UnauthorizedException.java
        │   ├── repository/
        │   │   ├── BookingRepository.java
        │   │   ├── CollegeRepository.java
        │   │   ├── DepartmentRepository.java
        │   │   ├── PeriodRepository.java
        │   │   ├── RoomRepository.java
        │   │   └── UserRepository.java
        │   └── service/
        │       ├── AuthService.java
        │       ├── BookingService.java
        │       ├── CollegeService.java
        │       └── DepartmentService.java
        └── resources/
            ├── application.properties
            └── static/
                └── index.html                ← Single Page App (no framework needed)
```

---

## 🔄 Booking Flow

```
Staff enters current time (e.g. "9.05 am")
       ↓
System checks: is time within college hours? (9.00 am – 5.15 pm)
       ↓
System checks: which booking window is currently open?
  → P1 window: 9.00 am – 9.15 am  ✅ 9.05 am is inside
       ↓
Shows all rooms (Available / Booked)
       ↓
Staff selects an available room
       ↓
System checks: is this room already booked for this period+date?
  → No? → Booking saved (first-come-first-served)
  → Yes? → "Already booked by [username]"
       ↓
After P1 class ends (10.05 am), the room becomes available again for P2 bookings
```

---

## ⚠️ Notes

- The database file is stored as `college_system.db` in the working directory.
- No external database server needed — SQLite is embedded.
- The frontend runs entirely in the browser and communicates with the Spring Boot REST API.
- CORS is enabled for all origins (`*`) for development convenience.
